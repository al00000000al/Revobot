<?php

namespace Revobot\Util;

class Time
{
    public static function today() {
        return date('Ymd');
    }
}
