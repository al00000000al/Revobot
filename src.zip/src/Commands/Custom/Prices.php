<?php

namespace Revobot\Commands\Custom;

class Prices
{
    public const PRICE_ALIAS = 10;
    public const PRICE_TEXT = 20;

}