<?php

const TG_KEY = '';
const VK_KEY = '';

const SECRET_KEY = '';
const TG_BOT_ADMINS = [];
const TG_BOT_ID = 0;
const FC_KEY = '';
const HUGGINGFACE_KEY = '';

const TLGRM_TYPESENSE_KEY = 'search on site';

const OPEN_WEATHER_MAP_API_KEY = '';


