<?php

namespace Revobot\Util;

class Dummy
{
    public static function exec(): string
    {
        return "";
    }
}