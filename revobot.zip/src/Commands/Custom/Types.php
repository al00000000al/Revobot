<?php

namespace Revobot\Commands\Custom;

class Types
{
    public const TYPE_ALIAS = 1;
    public const TYPE_TEXT = 2;

}